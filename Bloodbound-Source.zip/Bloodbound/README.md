# BLOODBOUND — THE LAST OATH

Ilyen carries **Ketsumei** through three acts. The Hollow Sovereign kills him in the morning. The blade brings him back to face the Sovereign again that afternoon. At night, the Hunter and the Brute guard the fortress where the Demon Overlord waits.

## Play

Open `Bloodbound.exe` and choose **Begin**. To edit the game, import `project.godot` in Godot 4.5.1 Standard and press **F5**.

| Key | Action |
| --- | --- |
| A / D or ← / → | Move |
| Space or ↑ | Jump. Release early to shorten the jump |
| J | Slash. Tap again for a combo, or press during a dodge for a dash slash |
| K | Heavy strike. Hold and release with 25 energy for a charged slash |
| Shift | Dodge or dash |
| L | Parry shortly before impact |
| E / U | Phantom Step / Soul Sever |
| Q / I | Death Reversal / Ancestral Echo |
| F | One Flash when prompted |
| Enter | Confirm or skip a cinematic |
| Esc / R | Pause / retry after defeat |

## Campaign

- **Morning · The Fallen Heir.** Follow the village road into the courtyard. The encounter ends when either fighter crosses its story health threshold. The Sovereign departs before Ilyen awakens.
- **Afternoon · The Ashen Hunt.** Cross the Old Stone Bridge, jump the forest briars, and get past the Hunter in the forest. The 350 HP Hollow Sovereign awaits at the shrine. Defeating him raises maximum health to 160, unlocks Phantom Step and Soul Sever, and opens the road to night.
- **Night · The Eclipse Hunt.** Cross the Moonlit Pass bridge, unlock Death Reversal at its checkpoint, and defeat both werewolves. The Hunter has 150 HP, the Brute has 220 HP, and they take turns attacking. Their defeat opens the gate and unlocks Ancestral Echo. The 800 HP Demon Overlord changes phases at 520 and 200 HP. At 40 HP, wait for **Strike Now** and press **F**.

Walk either way across both bridges. Turning back keeps the latest checkpoint and previously defeated enemies. **Retry** restores the checkpoint's current run, health tier, abilities, and charges. **Return to Title** discards the current run. **Begin** starts in the village with 120 HP and the initial abilities. Checkpoints are session-local.

The [asset manifest](ASSET_MANIFEST.md) covers sources, credits, and missing assets. See the [art import guide](ART_IMPORT_GUIDE.md) for adding sprites, backgrounds, and sound. Audio Settings has separate **Music** and **Effects** controls.

## Test and export

Run from the project folder with Godot 4.5.1 and the matching Windows export templates.

```powershell
godot --headless --editor --import --quit
godot --headless --fixed-fps 60 --script res://tests/smoke.gd
godot --headless --script res://tests/weapon.gd
godot --headless --fixed-fps 60 --script res://tests/smoke.gd -- --no-art
godot --headless --fixed-fps 60 --script res://tests/smoke.gd -- --base-duel
godot --fixed-fps 60 --script res://tests/display.gd
```

The **Windows Desktop** export produces a standalone x86-64 executable. Keep the [asset terms](ASSET_MANIFEST.md) with the project when preparing a public release.

